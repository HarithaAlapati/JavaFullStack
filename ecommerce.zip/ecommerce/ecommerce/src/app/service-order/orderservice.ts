import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../order-service/order-types';

@Injectable({
  providedIn: 'root'
})
export class Orderservice {
   private apiUrl:string = "http://localhost:8081/api/customers";

   constructor(private http:HttpClient){}

   
  addOrder(orders:any) : Observable<any> {
    return this.http.post(`${this.apiUrl}`, orders);
  }

  getOrders(): Observable<Order[]> {
  return this.http.get<Order[]>(this.apiUrl);
  }
  deleteOrder(id:number|undefined):Observable<any>{
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
  getOrderById(id:number):Observable<any>{
    return this.http.get(`${this.apiUrl}/${id}`);
  }
  updateOrder(id:number,orders:Order):Observable<any>{
    return this.http.put(`${this.apiUrl}/${id}`,orders);
  }
  
}
