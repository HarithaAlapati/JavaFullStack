import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomer } from './view-customer';
import { provideZonelessChangeDetection } from '@angular/core';

describe('ViewCustomer', () => {
  let component: ViewCustomer;
  let fixture: ComponentFixture<ViewCustomer>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewCustomer],
      providers: [provideZonelessChangeDetection()]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewCustomer);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});