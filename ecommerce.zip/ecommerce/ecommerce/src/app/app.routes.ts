import { Routes } from '@angular/router';
import { ViewCustomer } from './customer-service/view-customer/view-customer';
import { AddCustomer } from './customer-service/add-customer/add-customer';
import { EditCustomer } from './customer-service/edit-customer/edit-customer';
import { Menu } from './menu/menu';

export const routes: Routes = [
    {path:'' , component:Menu},
    {path:'customer', component:ViewCustomer},
    {path:'add-customer', component:AddCustomer},
    {path:'edit-customer/:id', component:EditCustomer}
];
