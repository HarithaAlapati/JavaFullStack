import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-order',
  imports: [],
  templateUrl: './edit-order.html',
  styleUrl: './edit-order.css'
})
export class EditOrder {

}
