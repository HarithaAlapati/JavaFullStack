import { Component } from '@angular/core';

@Component({
  selector: 'app-view-order',
  imports: [],
  templateUrl: './view-order.html',
  styleUrl: './view-order.css'
})
export class ViewOrder {

}
