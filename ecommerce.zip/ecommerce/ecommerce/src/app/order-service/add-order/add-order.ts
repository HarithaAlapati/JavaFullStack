import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Orderservice } from '../../service-order/orderservice';

@Component({
  selector: 'app-add-order',
  imports: [FormsModule],
  templateUrl: './add-order.html',
  styleUrl: './add-order.css'
})
export class AddOrder {
     order ={
     id:0
  }
  message='';

  constructor(private orderService:Orderservice, private router:Router){}

  async onSubmit() {
    console.log("Submitting order:", this.order);

    this.orderService.AddOrder(this.order).subscribe({
      next: (response: any) => {
        console.log("Order saved:", response);
        this.message = "Order added successfully!";
        this.router.navigate(['/order']);
      },
      error: (err: any) => {
        console.error("Error while saving order:", err);
        this.message = "Error adding order!";
      }
    });
  }


}
