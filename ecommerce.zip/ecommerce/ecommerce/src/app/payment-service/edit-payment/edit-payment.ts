import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-payment',
  imports: [],
  templateUrl: './edit-payment.html',
  styleUrl: './edit-payment.css'
})
export class EditPayment {

}
