import { Component } from '@angular/core';

@Component({
  selector: 'app-add-payment',
  imports: [],
  templateUrl: './add-payment.html',
  styleUrl: './add-payment.css'
})
export class AddPayment {

}
