import { Component } from '@angular/core';

@Component({
  selector: 'app-view-payment',
  imports: [],
  templateUrl: './view-payment.html',
  styleUrl: './view-payment.css'
})
export class ViewPayment {

}
