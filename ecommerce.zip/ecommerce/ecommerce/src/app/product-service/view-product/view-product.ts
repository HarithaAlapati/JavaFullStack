import { Component } from '@angular/core';

@Component({
  selector: 'app-view-product',
  imports: [],
  templateUrl: './view-product.html',
  styleUrl: './view-product.css'
})
export class ViewProduct {

}
