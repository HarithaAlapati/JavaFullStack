import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-product',
  imports: [],
  templateUrl: './edit-product.html',
  styleUrl: './edit-product.css'
})
export class EditProduct {

}
