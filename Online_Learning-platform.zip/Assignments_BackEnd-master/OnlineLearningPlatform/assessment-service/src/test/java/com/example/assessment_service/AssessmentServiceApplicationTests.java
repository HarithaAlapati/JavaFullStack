package com.example.assessment_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
