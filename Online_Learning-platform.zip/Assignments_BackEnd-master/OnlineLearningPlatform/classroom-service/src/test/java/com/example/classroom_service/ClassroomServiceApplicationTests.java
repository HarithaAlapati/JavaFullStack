package com.example.classroom_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassroomServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
